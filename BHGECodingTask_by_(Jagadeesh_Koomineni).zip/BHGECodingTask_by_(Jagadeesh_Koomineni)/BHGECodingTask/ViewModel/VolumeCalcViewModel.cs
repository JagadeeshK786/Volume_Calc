﻿using BHGECodingTask.Commands;
using BHGECodingTask.Model;
using BHGETestTask.Services;
using System;
using System.ComponentModel;
using System.Windows.Input;

namespace BHGECodingTask.ViewModel
{
    public class VolumeCalcViewModel : INotifyPropertyChanged
    {
        private ReservoirModel model = new ReservoirModel();

        public ICommand RadioCommand { get; set; }

        public ICommand CalulateCommand { get; set; }

        public VolumeCalcViewModel()
        {
            RadioCommand = new ReservoirCommand(RadioExecuteMethod, CanRadioExecuteMethod);
            CalulateCommand = new ReservoirCommand(CalculateExecuteMethod, CanCalculateExecuteMethod);
            model.FluidContact = 3000;
            model.DeltaHeight = 100;
            model.Unit = VolumeUnit.CubicMeter;
            model.GridCell = new Cell(200, 200);
        }

        public string CsvStream
        {
            get { return model.CsvStream; }
            set
            {
                model.CsvStream = value;
                OnPropertyChanged("CsvStream");
            }
        }

        public string FluidContact
        {
            get { return Convert.ToString(model.FluidContact); }
            set
            {
                double nFluidContact;
                model.FluidContact = (double.TryParse(value, out nFluidContact)) ? nFluidContact : 0;
                OnPropertyChanged("FluidContact");
            }
        }

        public string DeltaHeight
        {
            get { return Convert.ToString(model.DeltaHeight); }
            set
            {
                double nDeltaHeight;
                model.DeltaHeight = (double.TryParse(value, out nDeltaHeight)) ? nDeltaHeight : 0;
                OnPropertyChanged("DeltaHeight");
            }
        }

        public string LengthOfCell
        {
            get { return Convert.ToString(model.GridCell.Length); }
            set
            {
                long nLength;
                nLength = (long.TryParse(value, out nLength)) ? nLength : 0;

                model.GridCell = new Cell(nLength, model.GridCell.Breadth);
                OnPropertyChanged("LengthOfCell");
            }
        }

        public string BreadthOfCell
        {
            get { return Convert.ToString(model.GridCell.Breadth); }
            set
            {
                long nBreadth;
                nBreadth = (long.TryParse(value, out nBreadth)) ? nBreadth : 0;

                model.GridCell = new Cell(model.GridCell.Length, nBreadth);
                OnPropertyChanged("BreadthOfCell");
            }
        }

        public string Volume
        {
            get { return Convert.ToString(model.Volume) + ((model.Volume > 0) ?"  " + model.Unit.ToString() : string.Empty); }
            set
            {
                double nVolume;
                model.Volume = (double.TryParse(value, out nVolume)) ? nVolume : 0;
                OnPropertyChanged("Volume");
            }
        }

        private void OnPropertyChanged(string propName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }

        private bool CanRadioExecuteMethod(object parameter)
        {
            if (parameter != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void RadioExecuteMethod(object parameter)
        {
            switch (parameter)
            {
                case "rdbFeets":
                    model.Unit = VolumeUnit.CubicFeet;
                    break;

                case "rdbBarrels":
                    model.Unit = VolumeUnit.Barrel;
                    break;

                case "rdbMeters":
                default:
                    model.Unit = VolumeUnit.CubicMeter;
                    break;
            }
        }

        private bool CanCalculateExecuteMethod(object parameter)
        {
            //Model validation
            if (model != null && model.TopLayerDepthList != null && model.FluidContact > 0 && model.DeltaHeight > 0
            && model.GridCell.Length > 0 && model.GridCell.Breadth > 0 && model.Unit >= 0)
            {
                return true;
            }
            return false;
        }
        
        //Calculate Volume Button's Even Handler
        private void CalculateExecuteMethod(object parameter)
        {
            double cellArea = GeometryUtilService.CalculateArea(model.GridCell.Length, model.GridCell.Breadth);

            double reservoirVolumeInFeet = GeometryUtilService.CalculateVolume(model.TopLayerDepthList, cellArea, model.DeltaHeight, model.FluidContact);

            switch (model.Unit)
            {
                case VolumeUnit.CubicFeet:
                    model.Volume = reservoirVolumeInFeet;
                    break;

                case VolumeUnit.Barrel:
                    model.Volume = reservoirVolumeInFeet * GeometryUtilService.CubicFeet2Barrel;
                    break;

                case VolumeUnit.CubicMeter:
                default:
                    model.Volume = reservoirVolumeInFeet * GeometryUtilService.CubicFeet2CubicMeter;
                    break;
            }
            OnPropertyChanged("Volume");
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
