﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;
using UserControl = System.Windows.Controls.UserControl;

namespace BHGECodingTask.View
{
    /// <summary>
    /// Interaction logic for VolumeCalcView.xaml
    /// </summary>
    public partial class VolumeCalcView : UserControl
    {
        public VolumeCalcView()
        {
            InitializeComponent();
        }

        private void BtnFileBrowse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.csv)|*.csv";
                openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    txtFilePath.Text = openFileDialog.FileName;
                    txtCSVData.Text = File.ReadAllText(openFileDialog.FileName);
                    txtVolume.Text = string.Empty;
                }
            }
            catch(Exception ex)
            {
               MessageBox.Show("The .csv file import is failed with error: " + ex.Message);
            }
        }
    }
}
