﻿using System.Collections.Generic;
using System.Linq;

namespace BHGETestTask.Services
{
    public enum VolumeUnit { CubicFeet, CubicMeter, Barrel };
    
    static class GeometryUtilService
    {

        // Calclates the area
        public static double CalculateArea(long length, long breadth)
        {
            return length * breadth;
        }

        // Calclates the Volume of an Irregular 3D shape
        public static double CalculateVolume(IList<double> TopDepthList, double CellArea, double DeltaHeight, double FluidContact)
        {
           double bottomDepth = 0;
           double DeltaHeightFt = DeltaHeight * Meter2Feet;
           double FluidContactFt = FluidContact * Meter2Feet;

            var aggregateHeight = TopDepthList.Aggregate(0.0, (sum, topDepth)
                                    => {
                                        bottomDepth = topDepth + DeltaHeightFt;
                                        sum += ((topDepth >= FluidContactFt) ? 0
                                            : ((bottomDepth > FluidContactFt) ? FluidContactFt - topDepth : bottomDepth - topDepth));
                                        return sum;
                                    });

            return CellArea * aggregateHeight;
        }

        public static double Meter2Feet = 3.28084;

        public static double CubicFeet2CubicMeter = 0.0283168;

        public static double CubicFeet2Barrel = 0.237476809;
    }

}
