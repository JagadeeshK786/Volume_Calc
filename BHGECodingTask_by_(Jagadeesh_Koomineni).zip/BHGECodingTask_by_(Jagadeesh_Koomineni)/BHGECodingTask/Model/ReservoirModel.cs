﻿using BHGETestTask.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;

namespace BHGECodingTask.Model
{
    public struct Cell
    {
        public long Length;
        public long Breadth;

        public Cell(long nLength, long nBreadth)
        {
            this.Length = nLength;
            this.Breadth = nBreadth;
        }
    }

    public class ReservoirModel : INotifyPropertyChanged
    {
        private string _csvStream;
        public List<double> _topLayerDepthList;

        public List<double> TopLayerDepthList { get; set; }
        
        public double FluidContact { get; set; } = 3000;

        public double DeltaHeight { get; set; } = 100;

        public Cell GridCell { get; set; } = new Cell(200, 200);

        public double Volume { get; set; }

        public string CsvStream
        {
            get { return _csvStream; }
            set
            {
                try
                {
                    _csvStream = value;
                    //Fill TopLayerDepthList
                    if (!string.IsNullOrEmpty(_csvStream))
                    {
                        var enumDepths = (from sDepthVal in _csvStream.Split(new char[] { ',', ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                                          let depth = double.Parse(sDepthVal)
                                          where !string.IsNullOrEmpty(sDepthVal)
                                          select depth).ToList<double>();
                        if (enumDepths != null && enumDepths.Count() > 0)
                            TopLayerDepthList = enumDepths;
                    }

                    OnPropertyChanged("CsvStream");
                    OnPropertyChanged("TopLayerDepthList");
                }
                catch (Exception ex)
                {
                    TopLayerDepthList = null;
                    OnPropertyChanged("TopLayerDepthList");
                    MessageBox.Show("The .csv file import is failed with error: " + ex.Message);
                }
            }
        }

        public VolumeUnit Unit { get; set; } = VolumeUnit.CubicMeter;

        private void OnPropertyChanged(string propName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
